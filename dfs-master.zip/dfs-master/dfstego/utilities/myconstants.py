red = 0
green = 1
blue=2
diffmax = 4
diffmin = -4
redmax= 256
redmin= -1

red_color_addition=8
red_color_addition_1 = 4
mask_pvd_source=1 
mask_green_label=254
mask_green_label_0=252
mask_green_label_1=253
mask_blue_label=254
mask_to_lsb_0=254
mask_decode_elements=3
mask_emb_block_source_0=248
mask_emb_block_source_1=6
mask_emb_block_pixel=252
mask_emb_pixel_end = 1
mask_emd_source_end= 1
mask_emd_source = 0
path_images_output = 'resources/images/output/'
path_images_input = 'resources/images/input/'
####constants in lsb-pvd-emd
pixels_in_block = 4
average_max_in_lsb_pvd_emd= 15
mask_merge_emd_source = 252
mask_merge_end_source = 2
mask_merge_source_emd_or_end=3
####commands
lsb = 'lsb'
pvd = 'pvd'
emd = 'emd'
merge= 'lsb-pvd-emd'

